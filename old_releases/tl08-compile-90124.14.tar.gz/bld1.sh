#!/bin/bash
# Build Step 1 - extracting / patching source file and build

. ./option
export CFLAGS
unset CXXFLAGS
unset LDFLAGS

cd $CMP_TEMP
echo "[clean ]"
rm -rf texlive-*-source uptex-0.25 
echo "[unpack] texlive-*-source.tar"
tar xf $SRC/texlive-*-source.tar
echo "[unpack] uptex-0.25.tar.gz"
tar zxf $SRC/uptex-0.25.tar.gz 
cd texlive-*-source/texk
echo "[unpack] makejvf-1.1a.tar.gz"
tar zxf $SRC/makejvf-1.1a.tar.gz
echo "[unpack] mendexk2.6e.tar.gz"
echo "[unpack] ptexenc-0.999.tar.gz"
tar zxf $SRC/mendexk2.6e.tar.gz
tar zxf $SRC/ptexenc-0.999.tar.gz
cd web2c
echo "[unpack] ptex-src-3.1.10.tar.gz"
tar zxf $SRC/ptex-src-3.1.10.tar.gz
echo "[unpack] eptex-*.tar.gz"
tar jxf $SRC/eptex-*.tar.bz2
mv ptex-src-3.1.10/ ptexdir
cd ..
mv makejvf-1.1a/ makejvf
mv mendexk2.6e/ mendexk
mv ptexenc-0.999/ ptexenc
echo "[patch ] ptexlive's patch"
bash ptexenc/patches/texlive2008.sh &>/dev/null
patch -p1 -d mendexk < ptexenc/patches/mendexk2.6e-ptexenc.patch  &>/dev/null
patch -p1 -d makejvf < ptexenc/patches/makejvf-1.1a-ptexenc.patch &>/dev/null
cd ..
echo "[copy  ] ptexdir -> eptexdir"
cp -r texk/web2c/ptexdir texk/web2c/eptexdir
cp  texk/web2c/eptex-*/* texk/web2c/eptexdir &>/dev/null
echo "[patch ] ep-tl08.patch"
patch -p1 < $SRC/ep-tl08.patch &>/dev/null
cd texk/dvipsk
echo "[unpack] dvipsk-5.97-p1.7b-tl.tar.gz"
tar zxf $SRC/dvipsk-5.97-p1.7b-tl.tar.gz 
echo "[patch ] dvipsk-5.97-p1.7b-tl.diff"
patch -p1 < dvipsk-5.97-p1.7b-tl.diff &>/dev/null
cd ../xdvik
echo "[patch ] xdvik-tl08.patch.gz"
zcat $SRC/xdvik-tl08.patch.gz | patch -p1 &>/dev/null
autoconf
cd ../web2c/
echo "[copy  ] ptexdir -> uptexdir"
cp -r ptexdir/ uptexdir
cd uptexdir
mv ptex-base.ch uptex-base.ch
mv ptftopl.ch uptftopl.ch
mv ppltotf.ch uppltotf.ch
mv pdvitype.ch updvitype.ch
mv jbibtex.ch  upjbibtex.ch
cd ../../../
echo "[copy  ] upovp2ovf"
cp texk/web2c/omegaware/ovp2ovf.web texk/web2c/omegaware/upovp2ovf.web 
cp texk/web2c/omegaware/ovp2ovf.ch texk/web2c/omegaware/upovp2ovf.ch 
echo "[patch ] uptex_src-0.25.patch"
patch -p2 -f < $CMP_TEMP/uptex-0.25/patch/ptetex3-20080616_uptex_src-0.25.patch &>/dev/null
cd texk/web2c/
echo "[copy  ] uptexdir -> euptexdir"
cp -r uptexdir/ euptexdir
cd euptexdir/      
cp ../eptexdir/etex.diff .
cd ../../..
echo "[patch ] up-tl08.patch"
patch -p1 < $SRC/up-tl08.patch &>/dev/null

cd $SRC
echo 
echo "*** I will build TeX Live 2008. Press Return Key. ***"
cd $CMP_TEMP/texlive-*-source
./Build $CONF_OPT 
